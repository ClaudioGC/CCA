<nav id="nav-below" class="row navigation" role="navigation">
	<div class="col-xs-6 nav-previous"><?php previous_post_link( '%link', '<span class="meta-nav">&larr;</span> %title' ); ?></div>
	<div class="col-xs-6 nav-next tright"><?php next_post_link( '%link', '%title <span class="meta-nav">&rarr;</span>' ); ?></div>
</nav>