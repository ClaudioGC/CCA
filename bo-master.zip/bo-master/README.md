bo
==

Tema tipográficamente elemental para Wordpress
v0.0.1

![bo](screenshot.png)

## Requeriemientos para Desarrollo
* node.js
* bower.io
* less compiler

## Dependencias
* [bootstrap](http://www.getbootstrap)
* [stampa](http://eadpucv.github.io/stampa)

## Plugins Compatibles
* [Github-updater](https://github.com/afragen/github-updater/tree/master): Para actualizar el tema desde wordpress
* [Footnotes](http://www.elvery.net/drzax/more-things/wordpress-footnotes-plugin/)
* [WP Instagram Widget](https://github.com/cftp/wp-instagram-widget)

### Widgets
* [Rich Related Posts](http://www.splicelicio.us/rich-related-posts-wordpress-plugin)