		<footer id="footer" role="contentinfo">
			<div id="copyright">
				<?php echo sprintf( __( '%1$s %2$s %3$s. código es poesía.', 'bo' ), date( 'Y' ), "<span class='flip'>&copy;</span>", esc_html( get_bloginfo( 'name' ) ) ); echo sprintf( __( ' tema por: %1$s.', 'bo' ), '<a href="http://wiki.ead.pucv.cl/">e[ad]</a>' ); ?>
			</div>
		</footer>
	</div>
<?php wp_footer(); ?>
</body>
</html>